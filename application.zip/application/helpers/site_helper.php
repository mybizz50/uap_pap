<?php

if(!function_exists('can_access_user'))
{
  function can_access_user($value)
  {
   echo "Hello world";
  }
}


?>