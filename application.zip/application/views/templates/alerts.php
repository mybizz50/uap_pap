<div class="alert alert-<?php echo $type ?>">
    <?php echo $msg; ?>
</div>