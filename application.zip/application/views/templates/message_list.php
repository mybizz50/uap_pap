<div class="span4 well">
	<span class="nav-header">Message</span>
	<ol>
		<li class="active">
			<a href="#">Link</a>
		</li>
		<li>
			<a href="#">Link</a>
		</li>
		<li>
			<a href="#">Link</a>
		</li>
		<li>
			<a href="#">Link</a>
		</li>
	</ol>
	<a href="#" class=" badge badge-info">More</a>
</div>