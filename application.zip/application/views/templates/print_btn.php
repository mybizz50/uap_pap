<style type="text/css">
	.print_btn {
		background: none repeat scroll 0 0 #2DA5DA;
		border: 2px solid #E5E5E5;
		border-radius: 0 0 0 0;
		font-size: 1.1em;
		outline: medium none;
		padding: 0.8em;
		resize: none;
		color:white;
		transition: border-color 0.3s ease 0s;
	}
</style>
<div style="text-align: left; padding: 20px">
	<a class="print_btn" target="_blank" href="<?php echo $purl; ?>">Export as excel</a>
</div>
