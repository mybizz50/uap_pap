<script>
$(function() {
    $('#replace_show_1').hide(); 
    $('#replace_show_2').hide();
	$('#replace_show_2 input,#replace_show_2 textarea, #replace_show_2 select').prop('required',false); 
    
    $('#type').change(function(){
        if($('#type').val() == '2') {
            $('#replace_show_1').show();
    	    $('#replace_show_2').show(); 
            $('#replace_show_2 input,#replace_show_2 textarea, #replace_show_2 select').prop('required',true);
    
        } else {
            $('#replace_show_1').hide(); 
            $('#replace_show_2').hide();
            $('#replace_show_2 input,#replace_show_2 textarea, #replace_show_2 select').prop('required',false); 
        } 
    });
	    
     


    $('#maintanence_show_1').hide(); 
    $('#maintanence_show_2').hide();
    $('#maintanence_show_2 input,#maintanence_show_2 textarea, #maintanence_show_2 select').prop('required',false); 
    $('#maintanence_show_3').hide(); 
    
    $('#type').change(function(){
        if($('#type').val() == '3') {
            $('#maintanence_show_1').show();
			$('#history_hide_1').hide();
			$('#history_hide_2').hide();
			$('#xizt_hide_1').hide(); 
			$('#xizt_hide_2').hide(); 
			$('#maintanence_show_3').show(); 
		
			$('#maintanence_show_2').show();
            $('#maintanence_show_2 input,#maintanence_show_2 textarea, #maintanence_show_2 select').prop('required',true); 
            $('#maintanence_show_3 input,#maintanence_show_3 textarea, #maintanence_show_3 select').prop('required',true); 
			$('#history_hide_2 input,#history_hide_2 textarea, #history_hide_2 select').prop('required',false);
			$('#xizt_hide_2 input,#xizt_hide_2 textarea, #xizt_hide_2 select').prop('required',false);
			
        } else {
            $('#maintanence_show_1').hide(); 
			$('#history_hide_1').show(); 
			$('#history_hide_2').show(); 
			$('#xizt_hide_1').show(); 
			$('#xizt_hide_2').show();
		 	$('#maintanence_show_2').hide();
            $('#maintanence_show_2 input,#maintanence_show_2 textarea, #maintanence_show_2 select').prop('required',false); 
		 	$('#history_hide_2 input,#history_hide_2 textarea, #history_hide_2 select').prop('required',true);
			$('#xizt_hide_2 input,#xizt_hide_2 textarea, #xizt_hide_2 select').prop('required',true);
		    $('#maintanence_show_3').hide(); 
			$('#maintanence_show_3 input,#maintanence_show_3 textarea, #maintanence_show_3 select').prop('required',false); 
		 		
        } 
    });
	
});</script>
<script type="text/javascript" src="/assets/new_assets/js/jquery-1.4.2.min.js"></script>

<?php
echo form_open_multipart('purchase/initiate_purchase', array('class'=>'formoid-metro-cyan', 'autocomplete'=>'off', 'style'=>"background-color:#e5e9ec;font-size:13px;font-family:'Open Sans','Helvetica Neue','Helvetica',Arial,Verdana,sans-serif;color:#666666;"));
 ?>
 <?php if(!empty($ferror)){ ?>
    <div class="alert alert-error">
        <strong>Ops ! </strong> <?php echo $ferror; ?>
    </div>
    <?php } ?>
    
	<div class="title">
		<h2><?php echo $purchase_cat['name']; ?></h2>
	</div>
    <input type="hidden" name="ds_id" value="<?php echo $deptInfo['ds_id']; ?>" />
    <input type="hidden" name="purchase_category" value="<?php echo $purchase_cat['id']; ?>" />
	<div  class="element-select" >
		<label class="title">Purchase type</label>
		<div class="small">
			<span>
				<select id="type" name="purchase_type">
                <?php 
                foreach($p_types as $type){
                    ?>
                    <option value="<?php echo $type['id'] ?>"><?php echo $type['name'] ?></option>
                    <?php
                }
                ?>
                
            </select> 
            <i></i></span>
		</div>
	</div>
	<div id="formW">
		<table width="350" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td width="140" align="left">
				<div class="element-select" >
					<label class="title">Item Category</label>
					<div>
						<span>
							<select name="item_category">
                <?php 
                foreach($item_cats as $item){
                    ?>
                    <option value="<?php echo $item['id']; ?>"><?php echo $item['name'] ?></option>
                    <?php
                }
                ?>
                
            </select> <i></i></span>
					</div>
				</div></td>
				<td width="160">
				<div class="element-input" >
					<label class="title">Item Name</label>
					<input name="item_name"  type="text" required/>
				</div></td>
			</tr>
		</table>
	</div>

	<div id="formW">
		<table width="340" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left">
				<div class="element-textarea" >
					<label class="title">Specification</label>					<textarea required class="small" name="specification" cols="10" rows="3" ></textarea>
</div>				</td>
			</tr>
		</table>
	</div>
	<div id="formW">
		<table width="340" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left">
				<div class="element-textarea" >
					<label class="title">Justification</label>					<textarea required class="small" name="justification" cols="10" rows="3" ></textarea>
</div>				</td>
			</tr>
		</table>
	</div>
	<div id="formW">
		<table width="340" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left">
				<div class="element-textarea" >
					<label class="title">Purpose Of Purchase</label>					<textarea required class="small" name="purchase_purpose" cols="10" rows="3" ></textarea>
</div>				</td>
			</tr>
		</table>
	</div>

	<div id="formW">
		<table width="100" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left">
				<div class="element-input" >
					<label class="title">Quantity</label>
					<input required  id="small_form" type="number" name="total_quantity" />
				</div><div class="element-input" ></div></td>
				<td >
				<div class="element-input" >
					<label class="title">Unit Price</label>
					<input required id="small_form"  type="number" name="unit_price" />
				</div></td>
				<td>
				<div class="element-input" >
					<label class="title">Total Price</label>
					<input required id="small_form"  type="number" name="estimated_cost" />
				</div></td>
			</tr>
		</table>
	</div>
	<div id="formW">
		<table width="200" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left">
				<div class="element-radio" >
					<label class="title">Payment Method</label>
					<div class="column column2">
						<input required type="radio" name="payment_mode" value="Cheque" />
						<span>Cheque</span>
						<br/>
					</div><span class="clearfix"></span>
					<div class="column column2">
						<input type="radio" name="payment_mode" value="Cash" />
						<span>Cash</span>
						<br/>
					</div><span class="clearfix"></span>
				</div></td>
			</tr>
		</table>
	</div>
	<div>
		<input id="attchmnt" type="checkbox" name="file_attched" value="Attachments" />
		<span><strong>Attachments</strong></span>
		<br/>
	</div>

	<div id="attchmnt_hide_show_1">
		<table width="593" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td width="230" align="left">
				<div class="element-file" >
					<label class="title">File</label><label >
						<div class="button">
							Choose File
						</div>
						<input type="file" class="file_input" name="file_name" />
						<div class="file_text">
							No file selected
						</div></label>
				</div></td>
				<td  align="left" >
				<div class="element-input" >
					<label class="title">No. Of Quotations</label>
					<input id="small_form"  type="number" name="no_of_quotation" />
				</div></td>
			</tr>
		</table>
	</div>
	<div id="attchmnt_hide_show_2">
		<table width="340" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left">
				<div class="element-textarea" >
					<label class="title">Comparative Statement</label>					<textarea class="small" name="comperetive_statement" cols="20" rows="5" ></textarea>
</div>				</td>
			</tr>
			<tr>
				<td align="left">
				<div class="element-textarea" >
					<label class="title">Justification</label>					<textarea class="small" name="quotation_justification" cols="20" rows="5" ></textarea>
</div>				</td>
			</tr>
		</table>
	</div>
	<div id="attchmnt_hide_show_3">
		<table width="230" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td width="230" align="left">
				<div class="element-input" >
					<label class="title">Recommended Supplier</label>
					<input class="large" type="text" name="recommended_supplier" />
				</div></td>
			</tr>
		</table>
	</div>
	<div id="maintanence_show_1" class="title">
		<h2>Inspection report</h2>
	</div>
	<div  id="maintanence_show_2">
		<table width="340" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left">
				<div class="element-textarea" >
					<label class="title">Present Status</label>					<textarea class="small" name="present_status" cols="20" rows="5" ></textarea>
</div>				</td>
			</tr>
		</table>
	</div>
	<div id="maintanence_show_3">
		<table width="350" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left">
				<div class="element-select" >
					<label class="title">Recommendation</label>
					<div class="large">
						<select name="recommendation">
                <?php 
                foreach($recommendations as $a){
                    ?>
                    <option value="<?php echo $a['id']; ?>"><?php echo $a['status'] ?></option>
                    <?php
                }
                ?>
            </select>
            
					</div>
				</div></td>
				<td>
				<div class="element-input" >
					<label class="title">Inspector name</label>
					<input class="large" type="text" name="inspector_name" />
				</div></td>
			</tr>
			<tr>
				<td>
				<div class="element-input" >
					<label class="title">Designation</label>
					<input class="large" type="text" name="inspector_designation" />
				</div></td>
				<td>
				<div class="element-date" >
					<label class="title">Inspection Date</label>
					<input class="large" placeholder="yyyy-mm-dd" type="date" name="inspection_date" />
				</div></td>
			</tr>
		</table>
	</div>

	<div id="xizt_hide_1" class="title">
		<h2>Existing Quantity</h2>
	</div>
	<div id="xizt_hide_2">
		<table width="350" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left">
				<div class="element-input" >
					<label class="title">Functioning</label>
					<input required class="large" type="text" name="total_existing_functional_quantity" />
				</div></td>
				<td >
				<div class="element-input" >
					<label class="title">Non-functioning</label>
					<input required class="large" type="text" name="total_existing_nonFunctional_quantity" />
				</div></td>
			</tr>
		</table>
	</div>
	<div id="replace_show_1" class="title">
		<h2>Replace Info</h2>
	</div>
	<div id="replace_show_2">
		<table width="340" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left">
				<div class="element-textarea" >
					<label class="title">Certified By<span>*</span></label>					<textarea class="small" name="certified_by" cols="20" rows="5"></textarea>
</div>				</td>
			</tr>
			<tr>
				<td align="left">
				<div class="element-textarea" >
					<label class="title">Storing place of previous item<span>*</span></label>					<textarea class="small" name="prev_item_storing_place" cols="20" rows="5" required></textarea>
</div>				</td>
			</tr>
		</table>
	</div>

	<div id="history_hide_1" class="title">
		<h2>Purchase History</h2>
	</div>
	<div id="history_hide_2">
		<table width="350" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left">
				<div class="element-date" >
					<label class="title">Date of last purchase</label>
					<input required class="large" placeholder="yyyy-mm-dd" type="date" name="last_purchase_date" />
				</div></td>
				<td>
				<div class="element-input" >
					<label class="title">Quantity of last purchase</label>
					<input required class="large" type="number" name="last_purchase_quantity" />
				</div></td>
			</tr>
			<tr>
				<td>
				<div class="element-input" >
					<label class="title">Price/rate of last purchase</label>
					<input required  type="number" name="last_purchase_unit_rate" />
				</div></td>
				<td>
				<div class="element-input" >
					<label class="title">Total amount of last purchase</label>
					<input required type="number" name="last_purchase_total_amount" />
				</div></td>
			</tr>
		</table>
	</div>
	<div class="title">
		<h2>Advance payment</h2>
	</div>
	<div>
		<table width="380" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="left">
				<div class="element-input" >
					<label class="title">Advance amount</label>
					<input class="large" required type="number" name="advance_amount" />
				</div></td>
				<td>
				<div class="element-input" >
					<label class="title">In favor of</label>
					<input required class="large" type="text" name="advance_in_favour_of" />
				</div></td>
			</tr>
			<tr>
				<td>
				<div class="element-date" >
					<label class="title">Date by which advance is required</label>
					<input required class="large" placeholder="yyyy-mm-dd" type="date" name="required_advance_date" />
				</div></td>
				<td>
				<div class="element-date" >
					<label class="title">Estimated date by which will be settled</label>
					<input required class="large" placeholder="yyyy-mm-dd" type="date" name="advance_settle_date" />
				</div></td>
			</tr>
		</table>
	</div>

	<div class="title">
		<h2>Others</h2>
	</div>
	<div>
		<table width="380" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td>
				<div class="element-input" >
					<label class="title">Budget Head</label>
					<input type="text" required name="budget_head" />
				</div></td>
				<td>
				<div class="element-input" >
					<label class="title">Provision Amount</label>
					<input type="number" required name="provision_amount" />
				</div></td>
			</tr>
			<tr>
				<td>
				<div class="element-input" >
					<label class="title">If fund is short,from which head could be adjusted</label>
					<input required type="text" name="adjusted_budget_if_not" />
				</div></td>
			</tr>

		</table>
	</div>

	<div class="submit">
		<input type="submit" value="Submit"/>
	</div>

</form>
<script type="text/javascript" src="/assets/new_assets/js/formoid-metro-cyan.js"></script>
