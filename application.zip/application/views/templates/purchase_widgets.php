<div class="span4 well">
	<span class="nav-header">Purchase completed</span>
	<ol>
		<li class="active">
			<a href="#">Link</a>
		</li>
		<li>
			<a href="#">Link</a>
		</li>
		<li>
			<a href="#">Link</a>
		</li>
		<li>
			<a href="#">Link</a>
		</li>
	</ol>
	<a href="#" class=" badge badge-info">More</a>
</div>
<div class="span4 well">
	<span class="nav-header">Purchase rejected</span>
	<ol>
		<li class="active">
			<a href="#">Link</a>
		</li>
		<li>
			<a href="#">Link</a>
		</li>
		<li>
			<a href="#">Link</a>
		</li>
		<li>
			<a href="#">Link</a>
		</li>
	</ol>
	<a href="#" class=" badge badge-info">More</a>
</div>
<div class="span4 well">
	<span class="nav-header">Notifications</span>
	<ol>
		<li class="active">
			<a href="#">Link</a>
		</li>
		<li>
			<a href="#">Link</a>
		</li>
		<li>
			<a href="#">Link</a>
		</li>
		<li>
			<a href="#">Link</a>
		</li>
	</ol>
	<a href="#" class=" badge badge-info">More</a>
</div>
