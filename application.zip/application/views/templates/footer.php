<link href="/assets/new_assets/css/footer.css" rel="stylesheet" type="text/css" />
<div id="footer">
<table bgcolor="#212121" width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td height="36" align="right"><div id="footer_style">Copyright © 2014 All rights reserved by <a id="footer_style" href="http://www.uap-bd.edu‎/" target="new" >University of Asia Pacific</a></div></td>
    <td></td>
  </tr>
</table></div>
</body>
</html>
