<div class="navbar navbar-inverse navbar-fixed-top">
	<div class="navbar-inner">
		<div class="container-fluid">
			<a href="#" class="brand"><img src="<?php echo base_url(); ?>/assets/img/logo.png" alt="logo"/></a>
			<h3 id="site_title">Purchase & Inventory Management</h3>
		</div>
	</div>
</div>
