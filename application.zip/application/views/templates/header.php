<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title; ?></title>

<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/new_assets/css/formoid-metro-cyan.css" type="text/css" />

<script type="text/javascript" src="/assets/new_assets/js/jquery-1.4.2.min.js"></script>

<link href="<?php echo base_url(); ?>/assets/new_assets/css/SideBarMenu.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>/assets/new_assets/css/QuickLink.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>/assets/new_assets/css/navbar.css" rel="stylesheet" type="text/css" />
<?php include 'assets/new_assets/js/attchmnt.php' ?>
<?php include 'assets/new_assets/js/sidebar_jquery_1.php' ?>
<?php include 'assets/new_assets/js/QuickLinkJquery.php' ?>
<style type="text/css">
    .text-error{
        color:red; 
    padding:4px;
}

</style>
</head>
<body class="blurBg-true" style="background-color:#e5e9ec">