
<!--<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $title; ?></title>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/assets/css/bootstrap-responsive.min.css"/>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/assets/css/style.css"/>
        <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/bootstrap.min.js"></script>
        <!--[if lt IE 9]>
        <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/PIE.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/assets/css/style_ie.css"/>
        <script src="<?php echo base_url(); ?>/assets/js/html5shiv.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/ie.js"></script>
        <![endif]-->
    <!--</head>

    <!--[if lt IE 9]>
    <body class="ie8">
    <![endif]-->
    <!--[if !lt IE 9]>-->
    <!--<body>
        <!--<![endif]-->