<div class="well sidebar-nav">
    <ul class="nav nav-list">
        <li class="nav-header">
            Quick links
        </li>
        <li>
            <a href="/purchase">Purchase</a>
        </li>
        <li>
            <a href="/stock">Stock</a>
        </li>
        <li>
            <a href="/admin">Admin</a>
        </li>
        
        <li>
            <a href="/user/logout">Logout</a>
        </li>
        <li class="nav-header">
            Notification
        </li>
        <li>
            <a href="/purchase/notifications">All notifications (<span class="badge badge-warning"><?php echo $notification_number ?></span>)</a>
        </li>
        <li class="nav-header">
            Distribution management
        </li>
        <li>
            <a href="/distribution/entry/">Distribute</a>
        </li>
        <li>
            <a href="/distribution/distribution_log">Distribution log</a>
        </li>
        <!--li>
            <a href="/stock/entry/manual">Manual input</a>
        </li-->
        
        

    </ul>
</div>
