<hr>
<footer>
	<p>
		&copy; Company 2013
	</p>
</footer>
</body>
</html>
<script>
    $(function(){
        $('.tooltip_class').tooltip();
        
    });
</script>