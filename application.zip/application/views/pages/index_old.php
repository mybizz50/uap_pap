<?php echo $header; ?>
<?php echo $nav_regular; ?>
<div class="container-fluid">
     <?php echo $login_form; ?>   
</div>
<?php echo $footer ?>