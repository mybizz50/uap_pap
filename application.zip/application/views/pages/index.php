<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title><?php echo $title; ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body class="blurBg-true" style="background-color:#e5e9ec">
<?php echo $login_form; ?>
</body>
</html>
