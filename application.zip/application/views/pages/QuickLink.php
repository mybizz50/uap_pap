
<table width="860" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="33%" height="39" align="left" valign="bottom" id="fontquick">Quick Links</td>
    <td width="34%">
    
    </td>
    <td width="33%">&nbsp;</td>
    <td width="33%">&nbsp;</td>
  </tr>
  <tr>
    <td height="86">
    <section id="test1">
    <div id="quickPurchase">
      Recent
      Purchase
      <div id="subpurchase">
      Show your recent purchase now
      </div>
    </div>
    <div id="SubQuickPurchase">
    No Recentsss Purchase
    </div>
    </section>
    </td>
    <td>
    <section id="test2">
    <div id="quickStock">
      Current
      Stock 
      <div id="subStock">Click Here to Show your Current Stock
      </div>
    </div>
    <div id="SubQuickStock">
    No Stock Available
    </div>
    </section>
    </td>
    <td>
    <section id="test3">
    <div id="quickReport">
      Report
      Now
      <div id="subReport">Click Here to Report
      </div>
    </div>
    <div id="SubQuickReport">
    No Report
    </div>
    </section>
    </td>
 
  </tr>
</table>
