<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Purchase extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */

    private $fields_for_attachment = array("file_name", "no_of_quotation", "comperetive_statement", "quotation_justification", "recommended_supplier");

    private $replace_item_fields = array("present_status", "recommendation", "inspector_name", "inspector_designation", "inspection_date");
    private $fields_for_cat_3 = array();

    function __construct() {
        parent::__construct();
        if ($this -> session -> userdata('logged_in') == FALSE) {
            redirect('/user','refresh');
        }

        $this -> load -> model('users');
        $access = $this->users->get_role_defination($this -> session -> userdata('role'));
        if(empty($access['purchase_mod_access'])){
            redirect('/page/page_not_found', 'refresh');    
        }

        if($this -> session -> userdata('registration_completed')==0){
         redirect('/user/complete_registration', 'refresh');   
        }
        
    }

    public function index() {
            $this->generate_page("Purchase :: Home", array('current_process_list'=>''));
        
    }

    public function category($cat = 1, $type = '') {
        $this -> load -> model('purchase_model');
        $ret = $this -> purchase_model -> getDept($this -> session -> userdata('id'));
        $form_data = array("purchase_cat" => $this -> purchase_model -> getPurchaseInfo($cat), "recommendations" => $this -> purchase_model -> getRecommendations(), "item_cats" => $this -> purchase_model -> getStockCategories(), "p_types" => $this -> purchase_model -> getPurchaseTypes(), "deptInfo" => array('ds_name' => $ret['ds_name'], 'ds_id' => $ret['department']));
        $this->generate_page('Purchase :: ' . $form_data['purchase_cat']['name'], array('purchase_form'=>$form_data));
    }

    public function pop_array(array &$array, $key) {
        if (array_key_exists($key, $array)) {
            $b = $array[$key];
            unset($array[$key]);
            return $b;
        }

        return null;
    }
    
    
    public function notifications(){
        $this -> load -> model('purchase_model');
        $ret = $this->purchase_model->getNotifications();
        $this->generate_page("Purchase :: Notifications", array('notification_list'=>array('listItems'=>$this->purchase_model->getNotifications())));
    }

    public function initiate_purchase() {
        $this -> load -> model('purchase_model');
        $this->load->model('users');
        $this->purchase_model->insert_purchase_data();

        $this->load->model('activity_log');

                $name = $this->users->get_full_name($this -> session -> userdata('id'));
                $role_1= $this->users->get_role_name($this -> session -> userdata('role'));
                $purchase_name = $this->input->post('item_name');

                $action =   "initiated purchase"; 
                
                $log_info = array(
                "activity_type"=>1,
                "executor"=>$this->session->userdata('id'),
                "executed_to"=>'',
                "description"=>"$name($role_1) $action for $purchase_name"
                ); 
               $this->activity_log->add_log($log_info);
                

        $this->generate_page("Purchase :: Initialized", array('alerts'=>array('type'=>'success','msg'=>'Purchase initialized')));

    }
    
    public function notification($id){
        $this -> load -> model('purchase_model');
        $ret = $this->purchase_model->getNotificationDetail($id);
        $this->generate_page("Purchase :: Notification details", array('notification_details'=>$ret));
    }
    
    public function quotation_details($id){
       $this -> load -> model('purchase_model');
       $this->generate_page("Purchase :: Quatation details", array('quotation_details'=>$this->purchase_model->get_quotation_details($id))); 
    }

    public function get_purchase($id){
        $this -> load -> model('purchase_model');
        $this->generate_page("Purchase :: Details", array('purchase_details'=>$this->purchase_model->get_purchase_info($id)));
    }
    
    public function process_notification(){
        
        //print_r($this->input->post()); 
        $id = $this->input->post('id');   
        $this -> load -> model('purchase_model');
        
        $this->purchase_model->process_notification($id);
        
                $this->load->model('activity_log');
                $this->load->model('department');

                $name_1 = $this->users->get_full_name($this -> session -> userdata('id'));
                $role_1= $this->users->get_role_name($this -> session -> userdata('role'));



                
                $action =   ""; 
                $activity_type = "";
                $t_id = "";


                if($this->input->post('status')==5){
                    $action =   "forwarded "; 
                    $activity_type = 2;
                    $t_id = $this->input->post('forward_id');
                }else if($this->input->post('status')==6){
                    $action =   "backward "; 
                    $activity_type = 3;
                    $t_id = $this->input->post('return_id');
                }else if($this->input->post('status')==3){
                    $action =   "completed "; 
                    $activity_type = 4;

                }

                $purchase_name = $this->purchase_model->get_purcase_name($this->input->post('purchase_id'));

                if(!empty($t_id)){
                    $name_2 = $this->users->get_full_name($t_id);
                    $role_2= $this->users->get_role_name($this->users->get_role_by_id($t_id));
                    $log_info = array(
                        "activity_type"=>$activity_type,
                        "executor"=>$this->session->userdata('id'),
                        "executed_to"=>$t_id,
                        "description"=>"$name_1($role_1) $action a purchase($purchase_name) to $name_2($role_2)"
                    );
                }else{
                    $log_info = array(
                        "activity_type"=>$activity_type,
                        "executor"=>$this->session->userdata('id'),
                        "executed_to"=>'',
                        "description"=>"$name_1($role_1) $action a purchase($purchase_name)"
                    );

                }

                

                 
               $this->activity_log->add_log($log_info);
                

        $this->generate_page("Purchase :: Status", array('alerts'=> array('type'=>'success','msg'=>'Your action is successfully completed')));
        
    }

    public function purcahse_status_list(){
        $user = $this -> session -> userdata('id');
        $this -> load -> model('purchase_model');
        
        $processed_purchase = $this->purchase_model->get_purchase_processed_by_user($user);
        $processList = array();
        foreach($processed_purchase as $a){
                $current_status=$this->purchase_model->get_current_purchase_status($a['purchase_id']);
                //print_r($current_status);
                $temp_1 = $this->purchase_model->get_purchase_details($current_status[0]['purchase_id']);
                //print_r($current_status);
                $process = array(
                        'id'=>$temp_1['id'],
                        'title'=>$temp_1['item_name']." ( ". $temp_1['created_date']." ) ",
                        'action'=>$this->purchase_model->get_status_msg($current_status[0]['id'])
                    );

                $processList[]=$process;
        }

        $this->generate_page("Purchase :: Status log",array('process_list'=>array('process'=>$processList)));
    }

    public function purchase_log($id=''){
        $this -> load -> model('purchase_model');
        
        if(empty($id) || count($temp_1 = $this->purchase_model->get_purchase_details($id))==0){
        $this->generate_page("Purchase :: Status", array('alerts'=> array('type'=>'error','msg'=>'Invalid Id')));
        return;    
        }
        

        $log = $this->purchase_model->get_log_list($id);
        $this->generate_page("Purchase :: Purchase log",array('purchase_log_list'=>array('purchase_log_list'=>$log,'title'=>$temp_1['item_name']." ( ". $temp_1['created_date']." ) ")));



           
    }
    
    private function generate_page($title, $pdata, $page='purchase'){
            $this -> load -> model('users');
            $this -> load -> model('purchase_model');
            //print_r(expression);
            $name = $this->users->get_full_name($this -> session -> userdata('id'));
            $data['header'] = $this -> load -> view("templates/header", array('title' => $title), TRUE);
            $data['nav_logged'] = $this -> load -> view("templates/nav_logged", array('name'=>$name,'notification_number'=>$this->purchase_model->count_notification()), TRUE);
            $data['sidebar'] = $this -> load -> view("templates/sidebar", array('access'=>$this->users->get_role_defination($this -> session -> userdata('role'))), TRUE);
            $content = '';
            foreach($pdata as $name => $value){
                $content.=$this -> load -> view("templates/".$name, $value, TRUE);
            }

            $data['content']=$content;
                        $data['footer'] = $this -> load -> view("templates/footer", '', TRUE);
            $this -> load -> view('pages/'.$page, $data);
    }

}
