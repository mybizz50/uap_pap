<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
	    $this->generate_page("404 :: Page not found", array('alerts'=> array('type'=>'error','msg'=>'Page not found')));
	}

	function __construct() {
		parent::__construct();
		if ($this -> session -> userdata('logged_in') == FALSE) {
			redirect('/user', 'refresh');
		}

		if($this -> session -> userdata('registration_completed')==0){
         redirect('/user/complete_registration', 'refresh');   
        }

        
	}

	public function page_not_found(){
		$this->generate_page("404 :: Page not found", array('alerts'=> array('type'=>'error','msg'=>'Page not found')));
	}

	public function home(){
		$this->generate_page("Home :: Welcome", array('alerts'=> array('type'=>'success','msg'=>'Welcome')));	
	}

	private function generate_page($title, $pdata, $page = 'stock') {
		$this -> load -> model('users');
		$this -> load -> model('purchase_model');
		$name = $this -> users -> get_full_name($this -> session -> userdata('id'));
		$data['header'] = $this -> load -> view("templates/header", array('title' => $title), TRUE);
		$data['nav_logged'] = $this -> load -> view("templates/nav_logged", array('name' => $name, 'notification_number' => $this -> purchase_model -> count_notification()), TRUE);
		$data['sidebar'] = $this -> load -> view("templates/sidebar", array('access'=>$this->users->get_role_defination($this -> session -> userdata('role'))), TRUE);
		$content = '';

		foreach ($pdata as $name => $value) {

			$content .= $this -> load -> view("templates/" . $name, $value, TRUE);
		}

		$data['content'] = $content;

		$data['footer'] = $this -> load -> view("templates/footer", '', TRUE);
		$this -> load -> view('pages/' . $page, $data);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */