<?php

class Role extends CI_Model {
    function __construct() {
        parent::__construct();
    }
   
   
function add_role() {
        $array = array(
            'name' => $this -> input -> post('name'), 
            'description' =>$this -> input -> post('description'),
            'create_date' =>date("Y-m-d H:i:s", time()),
            'stock_mod_access'=>isset($_POST['stock_mod_access'])?1:0,
            'admin_mod_access'=>isset($_POST['admin_mod_access'])?1:0,
            'user_mod_access'=>isset($_POST['user_mod_access'])?1:0,
            'purchase_mod_access'=>isset($_POST['purchase_mod_access'])?1:0,
            'read_only'=>isset($_POST['read_only'])?1:0
        
        );
        
        $this->db->insert('role', $array); 
        return $this -> db -> count_all_results()?TRUE:FALSE;    
    }    

function get_role(){
    $query = $this->db->get('role');
    return $query->result_array();
}

function update_role($id){
    $array = array(
            'name' => $this -> input -> post('name'), 
            'description' =>$this -> input -> post('description'),
            'stock_mod_access'=>isset($_POST['stock_mod_access'])?1:0,
            'admin_mod_access'=>isset($_POST['admin_mod_access'])?1:0,
            'user_mod_access'=>isset($_POST['user_mod_access'])?1:0,
            'purchase_mod_access'=>isset($_POST['purchase_mod_access'])?1:0,
            'read_only'=>isset($_POST['read_only'])?1:0
        
        );
            
    $this->db->where('id', $id);
    $this->db->update('role', $array); 
    $res1 = $this -> db -> count_all_results();
    return $res1==1?TRUE:FALSE;  
}    

function change_status($id,$status){
    $array = array(
            'role_status' => $status
        
        );
        
    $this->db->where('id', $id);
    $this->db->update('role', $array); 
    $res1 = $this -> db -> count_all_results();
    return $res1==1?TRUE:FALSE;  
}    

    
}
?>