<?php
class Purchase_model extends CI_Model {
    private $step_hierarchy ;
        
   private $step_hierarchy_a = array( 
        
        array('role_id' => 8, 'is_department_specific' => TRUE), 
        array('role_id' => 7, 'is_department_specific' => TRUE), 
        array('role_id' => 16, 'is_department_specific' => FALSE),
        array('role_id' => 6, 'is_department_specific' => FALSE));
   
   
   private $step_hierarchy_b = array( 
        array('role_id' => 8, 'is_department_specific' => TRUE), 
        array('role_id' => 7, 'is_department_specific' => TRUE), 
        array('role_id' => 16, 'is_department_specific' => FALSE),
        array('role_id' => 6, 'is_department_specific' => FALSE));
   
   private $step_hierarchy_c = array( 
        array('role_id' => 8, 'is_department_specific' => TRUE), 
        array('role_id' => 7, 'is_department_specific' => TRUE), 
        array('role_id' => 16, 'is_department_specific' => FALSE), 
        array('role_id' => 5, 'is_department_specific' => FALSE), 
        array('role_id' => 6, 'is_department_specific' => FALSE));
   
   private $step_hierarchy_d = array( 
        array('role_id' => 8, 'is_department_specific' => TRUE), 
        array('role_id' => 7, 'is_department_specific' => TRUE), 
        array('role_id' => 16, 'is_department_specific' => FALSE), 
        array('role_id' => 5, 'is_department_specific' => FALSE), 
        array('role_id' => 6, 'is_department_specific' => FALSE));
   
   private $step_hierarchy_e = array( 
        array('role_id' => 8, 'is_department_specific' => TRUE), 
        array('role_id' => 7, 'is_department_specific' => TRUE), 
        array('role_id' => 16, 'is_department_specific' => FALSE), 
        array('role_id' => 5, 'is_department_specific' => FALSE), 
        array('role_id' => 4, 'is_department_specific' => FALSE),
        array('role_id' => 6, 'is_department_specific' => FALSE));
          
             
    private $last_purchase_id;
    private $user_id = 1;
    private $last_log_id = 0;
    private $purchase_category = 1;
    
    function __construct() {
        parent::__construct();
    }

    public function getPurchaseTypes() {
        $query = $this -> db -> get('purchase_type');
        return $query -> result_array();
    }

    public function getPurchaseTypeName($id) {
        $query = $this -> db -> get_where('purchase_type', array('id' => $id));
        $ret = $query -> result_array();
        return count($ret)?$ret[0]['name']:FALSE;
    }

    public function getStockCategories() {
        $query = $this -> db -> get_where('stock_category', array('stock_category_status' => 1));
        return $query -> result_array();
    }

    public function getStockCategory($id) {
        $query = $this -> db -> get_where('stock_category', array('id' => $id));
        $ret = $query -> result_array();
        return $ret[0]['name'];
    }

    public function getRecommendations() {
        $query = $this -> db -> get('recommendation_maintenance');
        $ret = $query -> result_array();
        return $ret;
    }

    public function getDept($id, $id_only = false) {
        $this -> db -> select('*');
        $this -> db -> from('user_profile');
        $this -> db -> where(array('user_id' => $id));
        $this -> db -> join('DepartmentSection', 'DepartmentSection.id = user_profile.department');
        $query = $this -> db -> get();
        $ret = $query -> result_array();
        return $id_only ? $ret[0]['id'] : $ret[0];
    }

    public function getDeptName($id) {
        $query = $this -> db -> get_where('DepartmentSection', array('id' => $id));
        $ret = $query -> result_array();
        return $ret[0]['ds_name'];
    }

    public function getPurchaseInfo($id) {
        $query = $this -> db -> get_where('purchase_category', array('id' => $id));
        $ret = $query -> result_array();
        return count($ret)?$ret[0]:null;
    }

    public function pop_array(array &$array, $key) {
        if (array_key_exists($key, $array)) {
            $b = $array[$key];
            unset($array[$key]);
            return $b;
        }

        return null;
    }

    private function upload_files($purchase_id=null) {
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png|xls|xlsx|pdf';
        $config['max_size'] = '2048';
        $file_name = empty($purchase_id)?$this->last_purchase_id:$purchase_id . "_" . $this -> session -> userdata('id') . "_" . $_FILES['file_name']['name'];
        $config['file_name'] = $file_name;
        $this -> load -> library('upload', $config);

        if (!$this -> upload -> do_upload('file_name')) {
            return '';
        } else {
            return $file_name;
        }
    }

    private function insert_inspection_report($data) {
        $this -> db -> insert('inspection_report', $data);
        $data = array('inspection_report_id' => ($this -> db -> affected_rows() != 1) ? '' : $this -> db -> insert_id(), );

        $this -> db -> where('id', $this -> last_purchase_id);
        $this -> db -> update('purchasing', $data);

        return ($this -> db -> affected_rows() != 1) ? '' : true;
    }

    private function insert_quotation_info($data) {
        $data['file_name'] = $this -> upload_files();
        $this -> db -> insert('quotation_detail', $data);
        $data = array('quotation_details_id' => ($this -> db -> affected_rows() != 1) ? '' : $this -> db -> insert_id(), );

        $this -> db -> where('id', $this -> last_purchase_id);
        $this -> db -> update('purchasing', $data);

        return ($this -> db -> affected_rows() != 1) ? '' : true;
    }
    
    private function insert_quotation_info_to_log($data) {
        $data['file_name'] = $this -> upload_files($data['purchase_id']);
        unset($data['purchase_id']);
        $this -> db -> insert('quotation_detail', $data);
        $data = array('quotation_details_id' => ($this -> db -> affected_rows() != 1) ? '' : $this -> db -> insert_id(), );

        $this -> db -> where('id', $this -> last_log_id);
        $this -> db -> update('purchase_management_status_log', $data);

        return ($this -> db -> affected_rows() != 1) ? '' : true;
    }
    

    public function register_log($array) {
        
        //print_r($array);
        $this -> db -> insert('purchase_management_status_log', $array);
        if ($this -> db -> affected_rows()) {
            $this -> last_log_id = $this -> db -> insert_id();
        }
        return ($this -> db -> affected_rows() != 1) ? FALSE : true;
    }

    public function init_initial_log() {
        $array = array("purchase_id" => $this -> last_purchase_id, "assigned_by" => $this -> session -> userdata('id'), "assigned_to" => $this -> session -> userdata('id'), "role_id" => $this -> session -> userdata('role'), "status" => 1);

        return $this -> register_log($array);
    }

    public function insert_purchase_data() {
        $post_array = $this -> input -> post();
        $quotation_info = array();
        $inspection_report = array();

        $is_file_attached = isset($post_array['file_attched']) ? true : FALSE;
        $has_inspection_report = $post_array['purchase_type'] == 3 ? true : FALSE;

        $quotation_info['file_name'] = $this -> pop_array($post_array, 'file_name');
        $quotation_info['no_of_quotation'] = $this -> pop_array($post_array, 'no_of_quotation');
        $quotation_info['comperetive_statement'] = $this -> pop_array($post_array, 'comperetive_statement');
        $quotation_info['quotation_justification'] = $this -> pop_array($post_array, 'quotation_justification');
        $quotation_info['recommended_supplier'] = $this -> pop_array($post_array, 'recommended_supplier');

        unset($post_array['file_attched']);

        $inspection_report['present_status'] = $this -> pop_array($post_array, 'present_status');
        $inspection_report['recommendation'] = $this -> pop_array($post_array, 'recommendation');
        $inspection_report['inspector_name'] = $this -> pop_array($post_array, 'inspector_name');
        $inspection_report['inspector_designation'] = $this -> pop_array($post_array, 'inspector_designation');
        $inspection_report['inspection_date'] = $this -> pop_array($post_array, "inspection_date");

        $post_array['inspection_report_id'] = '';

        $post_array['created_by'] = $this -> session -> userdata('id');

        $this -> db -> insert('purchasing', $post_array);
        $this -> last_purchase_id = ($this -> db -> affected_rows() != 1) ? null : $this -> db -> insert_id();
        if ($has_inspection_report) {
            $this -> insert_inspection_report($inspection_report);
        }

        if ($is_file_attached) {
            $this -> insert_quotation_info($quotation_info);
        }
        if ($this -> init_initial_log()) {
            $this -> create_notification($this -> session -> userdata('id'), 1);
        }
        //$this -> init_initial_log();
    }

    public function generate_notification_msg($status, $logid=null) {
        $query = $this -> db -> get_where('purchase_management_status_log', array('id' => (empty($logid)) ? $this -> last_log_id : $logid));
        $ret = $query -> result_array();
        $a = $ret[0];
        $msg = "";
        switch($status) {
            case 1 : {
                $msg = "Purchase initialized by you";
                break;
            }
            case 2 : {
                $msg = "Purchase rejected " . $this -> get_user_name($a['assigned_by']) . "(" . $this -> get_role_name_by_user_id($a['assigned_by']) . ")";
                break;
            }

            case 3 : {
                $msg = "Purchase marked completed by " . $this -> get_user_name($a['assigned_by']) . "(" . $this -> get_role_name_by_user_id($a['assigned_by']) . ")";
                break;
            }

            case 4 : {
                $msg = "Bil paid for a purchase (#" . $a['purchase_id'] . ")";
                break;
            }

            case 5 : {
                $msg = "Purchase request forwarded to you";
                break;
            }

            case 6 : {
                $msg = "Purchase request returned back to you";
                break;
            }default : {
                break;
            }
        }

        return $msg;

    }

    public function create_notification($for, $status) {
        
        $a = array("notification_for" => $for, "msg" => $this -> generate_notification_msg($status), "log_id " => $this -> last_log_id);
       // print_r($a);
        $this -> db -> insert('purchase_notifications', $a);
        return ($this -> db -> affected_rows() != 1) ? FALSE : true;
    }

    public function get_log_status_name($id) {
        $query = $this -> db -> get_where('purchase_related_status', array('id' => $id));
        return ($this -> db -> affected_rows() != 1) ? FALSE : true;
    }

    public function is_purchase_completed($id) {
        $query = $this -> db -> get_where('purchasing', array('id' => $id, 'purchase_status' => 'Completed'));
        $ret = $query -> result_array();
        return ($this -> db -> affected_rows() != 1) ? null : $ret[0]['status'];
    }

    public function get_current_purchase_status($id) {
        $this->db->order_by('time','desc');
        $ret = $this->db->get_where('purchase_management_status_log',array('purchase_id'=>$id),1);
        return $ret->result_array();
    }

    public function get_user_name($id) {
        $query = $this -> db -> get_where('user_profile', array('user_id' => $id));
        $ret = $query -> result_array();
        return ($this -> db -> affected_rows() != 1) ? null : $ret[0]['first_name'] . " " . $ret[0]['last_name'];
    }

    public function get_role_name_by_user_id($id, $id_only = false) {
        $query = $this -> db -> get_where('users', array('id' => $id));
        $ret = $query -> result_array();
        $role_id = $ret[0]['role_id'];
        $query = $this -> db -> get_where('role', array('id' => $role_id));
        $ret = $query -> result_array();

        return ($this -> db -> affected_rows() != 1) ? null : $id_only ? $ret[0]['id'] : $ret[0]['name'];

    }

    public function getNotifications() {
        $notificationList = array();
        $this -> db -> order_by("create_date", "desc");
        $query = $this -> db -> get_where('purchase_notifications', array('notification_for' => $this -> session -> userdata('id'), "is_processed" => 0));
        $ret = $query -> result_array();
        foreach ($ret as $a) {
            $query = $this -> db -> get_where('purchase_management_status_log', array('id' => $a["log_id"]));
            $data = $query -> result_array();
            $notification['id'] = $a['id'];
            $notification['message'] = $this -> generate_notification_msg($data[0]['status'], $a["log_id"]);
            $notification['date'] = $a['create_date'];
            $notificationList[] = $notification;
        }

        return $notificationList;
    }

    public function count_notification() {
        return count($this -> getNotifications());
    }

    public function getLogStatusInfo($id) {
        //echo $id;
        $query = $this -> db -> get_where('purchase_management_status_log', array('purchase_id' => $id));
        $ret = $query -> result_array();
        return count($ret)?$ret[0]:array();

    }

    public function get_purchase_details($id) {
        $query = $this -> db -> get_where('purchasing', array('id' => $id));
        $ret = $query -> result_array();
        return count($ret)?$ret[0]:array();
    }

    public function get_purcase_name($id){
        $ret = $this->get_purchase_details($id);
        return $ret ? $ret['item_name']:"none";
    }

    public function get_quotation_details($id) {
        $query = $this -> db -> get_where('quotation_detail', array('id' => $id));
        $ret = $query -> result_array();
        return count($ret)?$ret[0]:array();
    }

    public function get_inspection_report($id) {
        $query = $this -> db -> get_where('inspection_report', array('id' => $id));
        $ret = $query -> result_array();
        return count($ret)?$ret[0]:array();
    }

    public function get_log_id_from_notification_id($id) {
        $query = $this -> db -> get_where('purchase_notifications', array('id' => $id));
        $ret = $query -> result_array();
        return $ret[0]['log_id'];
    }

    public function get_purchase_id_from_notification_id($id) {
        $query = $this -> db -> get_where('purchase_management_status_log', array('id' => $this -> get_log_id_from_notification_id($id)));
        $ret = $query -> result_array();
        return $ret[0]['purchase_id'];
    }
    
    public function get_log_list($id){
        $query = $this->db->get_where('purchase_management_status_log',array('purchase_id'=>$id));
        $ret = $query->result_array();
        $log_list = array();
        foreach($ret as $a){
            $x['time'] = $a['time'];
            $x['assigned_by'] = $this->get_user_name($a['assigned_by'])." (".$this->get_role_name_by_user_id($a['assigned_by']).")";
            $x['assigned_to'] = $this->get_user_name($a['assigned_to'])." (".$this->get_role_name_by_user_id($a['assigned_to']).")";
            $x['comments'] = $a['comments'];
            $x['quotation_details_id']=$a['quotation_details_id'];
            $x['action'] = $this->get_status_msg($a['id']);
            $log_list[]=$x;
        }
        
        return $log_list;
    }
    
    public function get_status_msg($log_id){
        $msg = '';
        $query = $this->db->get_where('purchase_management_status_log',array('id'=>$log_id));
        $ret = $query->result_array();
        switch((int)$ret[0]['status']){
            case 1:{
                $msg = "Initialized by ".$this->get_user_name($ret[0]['assigned_by'])." (".$this->get_role_name_by_user_id($ret[0]['assigned_by']).")";
                break;
            }
            case 2:{
                $msg = "Rejected by ".$this->get_user_name($ret[0]['assigned_by'])." (".$this->get_role_name_by_user_id($ret[0]['assigned_by']).")";
                break;
            }
            case 3:{
                $msg = "Completed by ".$this->get_user_name($ret[0]['assigned_by'])." (".$this->get_role_name_by_user_id($ret[0]['assigned_by']).")";
                break;
            }
            case 4:{
                $msg = "Bill paid by ".$this->get_user_name($ret[0]['assigned_by'])." (".$this->get_role_name_by_user_id($ret[0]['assigned_by']).")";
                break;
            }
            case 5:{
                $msg = "Forwarded to ".$this->get_user_name($ret[0]['assigned_to'])." (".$this->get_role_name_by_user_id($ret[0]['assigned_to']).")";
                break;
            }
            case 6:{
                $msg = "Returned back to ".$this->get_user_name($ret[0]['assigned_to'])." (".$this->get_role_name_by_user_id($ret[0]['assigned_to']).")";
                break;
            }default:{
                break;
            }
            
            

        }
        return $msg;
    }

    public function getNotificationDetail($id) {
        $quotation_detail = array();
        $inspection_report = array();
        $notification = $this -> getLogStatusInfo($this -> get_purchase_id_from_notification_id($id));
        $purchase_info = $this -> get_purchase_details($notification['purchase_id']);
        $this->purchase_category = $this -> getPurchaseInfo($purchase_info['purchase_category']);
        $this->set_step_hierarchy();
        
        $purchase_info['purchase_category'] = $this->purchase_category;
        $purchase_info['ds_id'] = $this -> getDeptName($purchase_info['ds_id']);
        $purchase_info['purchase_type'] = $this -> getPurchaseTypeName($purchase_info['purchase_type']);
        $purchase_info['item_category'] = $this -> getStockCategory($purchase_info['item_category']);
        $purchase_info['created_by'] = $this -> get_user_name($purchase_info['created_by']) . " (" . $this -> get_role_name_by_user_id($purchase_info['created_by']) . ")";
        $purchase_info['notification_id']=$id;
                if($next = $this->get_forward_to_id($this -> session -> userdata('id'),$purchase_info['id'])){
            $x['forward_id']=$next;
            $x['forward_name']=$this->get_user_name($next)." (".$this->get_role_name_by_user_id($next).")";
            $purchase_info['forward_list'][]=$x;
            
        }
        
        
        
        if(count($list = $this->get_return_list($id))){
            $purchase_info['return_list'] = $list;
        }
        $logList = $this->get_log_list($purchase_info['id']);
        $purchase_info['purchase_log_list'] = $logList;
        return array_merge($quotation_detail, $inspection_report, $purchase_info);

    }

    public function get_purchase_info($id) {
        $quotation_detail = array();
        $inspection_report = array();
        $purchase_info = $this -> get_purchase_details($id);
        $purchase_info['purchase_category'] = $this -> getPurchaseInfo($purchase_info['purchase_category']);
        $purchase_info['ds_id'] = $this -> getDeptName($purchase_info['ds_id']);
        $purchase_info['purchase_type'] = $this -> getPurchaseTypeName($purchase_info['purchase_type']);
        $purchase_info['item_category'] = $this -> getStockCategory($purchase_info['item_category']);
        $purchase_info['created_by'] = $this -> get_user_name($purchase_info['created_by']) . " (" . $this -> get_role_name_by_user_id($purchase_info['created_by']) . ")";
        $purchase_info['notification_id']=$id;
        if (!empty($purchase_info['inspection_report_id'])) {
            $inspection_report = $this -> get_inspection_report($purchase_info['inspection_report_id']);
        }

        if (!empty($purchase_info['quotation_details_id'])) {
            $inspection_report = $this -> get_quotation_details($purchase_info['quotation_details_id']);
        }
        
                return array_merge($quotation_detail, $inspection_report, $purchase_info);

    }

    public function get_return_list($id){
        $purchase_id = $this->get_purchase_id_from_notification_id($id);
        $query = $this->db->get_where('purchase_management_status_log',array('purchase_id'=>$purchase_id));
        $ret = $query->result_array();
        $return_list = array();
        $cu_role = $this->get_role_name_by_user_id($this -> session -> userdata('id'),true);
        $current_role_pos = $this->role_position($cu_role);             
        foreach($ret as $a){
            $role_id = $this->get_role_name_by_user_id($a['assigned_to'],true);
            if($this->role_position($role_id) < $current_role_pos){
                $return_list[$a['assigned_to']]=$this->get_user_name($a['assigned_to'])." (".$this->get_role_name_by_user_id($a['assigned_to']).")";
                
            }    
        }
        return $return_list;
    }
    
    public function role_position($role_id){

        $current_role_pos = -1;
        foreach ($this->step_hierarchy as $b) {
            $current_role_pos++;
            $found = 0;
            if ($b['role_id'] == $role_id){
                            $found = 1;
                            break;
                        }
            
        }
        return $found?$current_role_pos :-1;
    }
    
    public function get_dept_from_purchase_id($id){
        $query = $this->db->get_where('purchasing',array('id'=>$id));
        $ret = $query->result_array();
        return $ret[0]['ds_id'];
    }

    public function get_forward_to_id($current_user,$purchase_id) {
        $role = $this -> get_role_name_by_user_id($current_user, true);
        $tmp = $this->get_purchase_details($purchase_id);
        $this->purchase_category = $tmp['purchase_category'];
        $this->set_step_hierarchy();
        $key = 0;
        foreach ($this->step_hierarchy as $a) {
            $key++;
            if ($a['role_id'] == $role)
                break;
        }
        if (array_key_exists($key, $this -> step_hierarchy)) {
            $next_role = $this -> step_hierarchy[$key]['role_id'];
            if ($this -> step_hierarchy[$key]['is_department_specific']) {
                $dept = $this -> get_dept_from_purchase_id($purchase_id);
                $this -> db -> select('*');
                $this -> db -> from('user_profile');
                $this -> db -> join('users', 'users.id = user_profile.user_id');
                $this -> db -> where(array('role_id' => $next_role,"department"=>$dept));
                $query = $this -> db -> get();
                $ret = $query -> result_array();

                return $ret[0]['id'];
            }else{
                $this -> db -> select('*');
                $this -> db -> from('users');
                $this -> db -> where(array('role_id' => $next_role));
                $query = $this -> db -> get();
                $ret = $query -> result_array();
                return $ret[0]['id'];
            }
        }else{
            return FALSE;
        }

    }
    
    public function get_purchase_initiator_id($id){
        $query_array=array('id'=>$id);
        $ret = $this->db->get_where('purchasing',$query_array);
        $ret = $ret->result_array();
        return $ret[0]['created_by'];
    }
    
    public function change_purchase_status($id,$status=0){
        $query_array=array('purchase_status'=>$status);
        $this->db->where('id',$id);
        $this->db->update('purchasing',$query_array);
        return ($this -> db -> affected_rows() != 1) ? FALSE : TRUE;
    }
    
    public function process_notification($id){
        $post_array = $this -> input -> post();
        unset($post_array['id']);
        $is_file_attached = isset($post_array['file_attched']) ? true : FALSE;
        $quotation_info['purchase_id'] = $post_array['purchase_id'];
        $quotation_info['file_name'] = $this -> pop_array($post_array, 'file_name');
        $quotation_info['no_of_quotation'] = $this -> pop_array($post_array, 'no_of_quotation');
        $quotation_info['comperetive_statement'] = $this -> pop_array($post_array, 'comperetive_statement');
        $quotation_info['quotation_justification'] = $this -> pop_array($post_array, 'quotation_justification');
        $quotation_info['recommended_supplier'] = $this -> pop_array($post_array, 'recommended_supplier');
        
        
        
        unset($post_array['file_attched']);
        if($post_array['status']==5){
            $post_array['assigned_to']=$post_array['forward_id'];
            unset($post_array['forward_id']);
            unset($post_array['return_id']);
        }else if($post_array['status']==6){
            $post_array['assigned_to']=$post_array['return_id'];
            unset($post_array['return_id']);
            unset($post_array['forward_id']);
            
        }else if($post_array['status']==3){
            $purchase_id = $this->get_purchase_id_from_notification_id($id);
            $post_array['assigned_to']=$this->get_purchase_initiator_id($purchase_id);
            $this->change_purchase_status($purchase_id,1);
            unset($post_array['return_id']);
            unset($post_array['forward_id']);
            
        }
        
        
        $post_array['assigned_by']=$this->session->userdata('id');
        
        
        
        $log_inserted = $this->register_log($post_array);
        
         
        if ($is_file_attached) {
            $this -> insert_quotation_info_to_log($quotation_info);
        }
        
        if($log_inserted){
            if($this->change_notification_status($id,1)){
               
                $this->create_notification($post_array['assigned_to'], $post_array['status']);   
            }
            
        }
        
        
        
    }

    private function set_step_hierarchy(){
        switch ($this->purchase_category) {
            case 1:
                $this->step_hierarchy = $this->step_hierarchy_a;
                break;
            
            case 2:
                $this->step_hierarchy = $this->step_hierarchy_b;
                break;
            
            case 3:
                $this->step_hierarchy = $this->step_hierarchy_c;
                break;
            
            case 4:
                $this->step_hierarchy = $this->step_hierarchy_d;
                break;
            
            case 5:
                $this->step_hierarchy = $this->step_hierarchy_e;
                break;
            
            default:
                $this->step_hierarchy = $this->step_hierarchy_a;
                break;
        }
    }

    public function change_notification_status($id,$is_processed=1){
        $this -> db -> where('id', $id);
        $this -> db -> update('purchase_notifications', array('is_processed'=>$is_processed));

        return ($this -> db -> affected_rows() != 1) ? FALSE : TRUE;
    }
    
    public function get_completed_purchase_list(){
        $query = array(
            "purchase_status"=>1
        );
        
        $ret = $this->db->get_where('purchasing',$query);
        return $ret->result_array();
    }

    public function get_purchase_processed_by_user($id){
        $this->db->distinct();
        $this->db->select('purchase_id');
        $this->db->from('purchase_management_status_log');
        $this->db->where('assigned_to',$id);
        $this->db->order_by('time','desc');

        $res = $this->db->get();
        return $res->result_array();
    }






}
?>