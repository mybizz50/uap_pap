// JavaScript Document
$(function(){
if (window.PIE) {
        $('.css3pie').each(function() {
            PIE.attach(this);
        });
    }	
});